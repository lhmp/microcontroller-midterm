/*
 * software_timer.h
 *
 *  Created on: Sep 21, 2022
 *      Author: maiph
 */

#ifndef __SOFTWARE_TIMER_
#define __SOFTWARE_TIMER_

extern int timer1_flag;

void setTimer(int duration);
void timerRun();


#endif
