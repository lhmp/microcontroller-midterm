/*
 * button.h
 *
 *  Created on: Sep 21, 2022
 *      Author: maiph
 */

#ifndef INC_BUTTON_H_
#define INC_BUTTON_H_

#include "main.h"

#define NORMAL_STATE SET
#define PRESSED_STATE RESET

int isButton1Pressed();
int isButton1LongPressed();
int isButton1DoublePressed();

void getKeyInput();


#endif /* INC_BUTTON_H_ */
